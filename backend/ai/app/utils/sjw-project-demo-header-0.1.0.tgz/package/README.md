# @sjw-project/demo-header

공통 데모 인증 헤더를 React 앱에서 라이브러리처럼 사용하기 위한 패키지입니다.

## 로컬 빌드

```bash
cd frontend/DemoHeader
npm install
npm run build
```

로컬 tarball로 다른 프로젝트에 설치하려면 다음을 실행합니다.

```bash
npm run pack:local
npm install /path/to/sjw-project-demo-header-0.1.0.tgz
```

## 사용법

```jsx
import DemoHeader from "@sjw-project/demo-header";
import "@sjw-project/demo-header/style.css";

export default function App() {
  return (
    <>
      <DemoHeader />
      {/* routes */}
    </>
  );
}
```

인증 서버 주소가 다르면 `apiBaseUrl`을 넘깁니다.

```jsx
<DemoHeader apiBaseUrl="https://auth.sjw-project.site" />
```

앱 내부 로그인 상태와 동기화해야 하는 경우 `DemoHeaderView`와 `useDemoAuth`를
조합해 프로젝트별 래퍼를 만들 수 있습니다.
